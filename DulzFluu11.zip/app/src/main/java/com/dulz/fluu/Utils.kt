package com.dulz.fluu

import android.app.ActivityManager
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.graphics.Color
import android.graphics.Rect
import android.media.AudioManager
import android.Manifest
import android.os.BatteryManager
import android.provider.Settings
import java.io.File
import rikka.shizuku.Shizuku

internal fun lum(c: Int): Int =
    (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c)) / 1000

/** Palet warna yang dipakai panel native. */
internal class Pal(val bg: Int, val surface: Int, val text: Int, val accent: Int) {
    val onAccent: Int get() = if (lum(accent) > 150) 0xFF0B0C0F.toInt() else Color.WHITE
}

/** Versi web sebuah aplikasi, dipakai sebagai jendela melayang cadangan. */
internal class WebApp(val url: String, val desktop: Boolean)

object Sys {

    private val WEB: Map<String, WebApp> = mapOf(
        "com.whatsapp" to WebApp("https://web.whatsapp.com", true),
        "com.whatsapp.w4b" to WebApp("https://web.whatsapp.com", true),
        "org.telegram.messenger" to WebApp("https://web.telegram.org/k/", true),
        "com.instagram.android" to WebApp("https://www.instagram.com/", false),
        "com.facebook.katana" to WebApp("https://m.facebook.com/", false),
        "com.facebook.orca" to WebApp("https://www.messenger.com/", true),
        "com.discord" to WebApp("https://discord.com/app", true),
        "com.google.android.youtube" to WebApp("https://m.youtube.com/", false),
        "com.twitter.android" to WebApp("https://x.com/", false),
        "com.zhiliaoapp.musically" to WebApp("https://www.tiktok.com/", false),
        "com.spotify.music" to WebApp("https://open.spotify.com/", true),
        "com.google.android.gm" to WebApp("https://mail.google.com/mail/mu/", false)
    )

    internal fun web(pkg: String): WebApp? = WEB[pkg]

    /** Membuka aplikasi lain berdasarkan nama paket (layar penuh). */
    fun open(ctx: Context, pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Perintah sekali pasang agar semua aplikasi bisa melayang (dijalankan lewat ADB / Debugging nirkabel). */
    fun adbCommand(ctx: Context): String =
        "pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"

    fun hasSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    private fun globalInt(ctx: Context, key: String): Int = try {
        Settings.Global.getInt(ctx.contentResolver, key, 0)
    } catch (e: Exception) {
        0
    }

    /** Jendela asli (freeform) dianggap siap bila fitur bawaan ada atau sudah dinyalakan. */
    fun freeformOn(ctx: Context): Boolean =
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT) ||
            globalInt(ctx, "enable_freeform_support") == 1

    /** Aplikasi yang tidak mendukung ubah ukuran dipaksa bisa, supaya semua aplikasi bisa melayang. */
    fun forcedResize(ctx: Context): Boolean = globalInt(ctx, "force_resizable_activities") == 1

    /** Menyalakan atau mematikan jendela melayang untuk semua aplikasi. Butuh izin WRITE_SECURE_SETTINGS. */
    fun setFloatAll(ctx: Context, on: Boolean): Boolean {
        if (!hasSecure(ctx)) return false
        return try {
            val v = if (on) 1 else 0
            Settings.Global.putInt(ctx.contentResolver, "enable_freeform_support", v)
            Settings.Global.putInt(ctx.contentResolver, "force_resizable_activities", v)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------ Shizuku

    /** "off" = Shizuku belum jalan, "ask" = perlu izin Shizuku, "ready" = siap dipakai. */
    fun shizukuState(): String = try {
        if (!Shizuku.pingBinder()) "off"
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "ready"
        else "ask"
    } catch (e: Throwable) {
        "off"
    }

    fun shizukuAsk(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
            // Shizuku tidak tersedia
        }
    }

    /** Menjalankan perintah shell lewat Shizuku. Mengembalikan true bila kode keluar 0. */
    private fun shizukuShell(args: Array<String>): Boolean {
        if (shizukuState() != "ready") return false
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, args, null, null) as Process
            proc.waitFor() == 0
        } catch (e: Throwable) {
            false
        }
    }

    /** Memberi izin WRITE_SECURE_SETTINGS ke aplikasi ini lewat Shizuku (setara perintah ADB). */
    fun shizukuGrant(ctx: Context): Boolean {
        val ok = shizukuShell(arrayOf("pm", "grant", ctx.packageName, "android.permission.WRITE_SECURE_SETTINGS"))
        return ok && hasSecure(ctx)
    }

    /** Seperti shizukuShell, tapi mengembalikan keluaran perintah (null bila gagal). */
    private fun shizukuOut(args: Array<String>): String? {
        if (shizukuState() != "ready") return null
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, args, null, null) as Process
            val text = proc.inputStream.bufferedReader().readText()
            proc.waitFor()
            text
        } catch (e: Throwable) {
            null
        }
    }

    /** Mencari nomor task sebuah aplikasi. -1 = tidak ada, -2 = Shizuku/perintah gagal. */
    fun findTaskId(pkg: String): Int {
        val out = shizukuOut(arrayOf("sh", "-c", "dumpsys activity activities | grep -E 'Task(Record)?[{]'")) ?: return -2
        val lines = out.lines().filter { it.contains(":$pkg ") || it.contains("=$pkg ") }
        val line = lines.firstOrNull { it.contains("freeform") } ?: lines.firstOrNull() ?: return -1
        val m = Regex("#(\\d+)").find(line) ?: return -1
        return m.groupValues[1].toInt()
    }

    /** Mengubah posisi dan ukuran jendela freeform. */
    fun resizeTask(taskId: Int, r: Rect): Boolean = shizukuShell(
        arrayOf("am", "task", "resize", taskId.toString(), r.left.toString(), r.top.toString(), r.right.toString(), r.bottom.toString())
    )

    fun forceStop(pkg: String): Boolean = shizukuShell(arrayOf("am", "force-stop", pkg))

    /** Tangkapan layar lewat shell, disimpan di Pictures/Screenshots. */
    fun screenshot(): Boolean {
        val path = "/sdcard/Pictures/Screenshots/DulzFluu_" + System.currentTimeMillis() + ".png"
        val ok = shizukuShell(arrayOf("sh", "-c", "mkdir -p /sdcard/Pictures/Screenshots && screencap -p " + path))
        if (ok) shizukuShell(arrayOf("am", "broadcast", "-a", "android.intent.action.MEDIA_SCANNER_SCAN_FILE", "-d", "file://" + path))
        return ok
    }

    /** Membuka aplikasi sebagai jendela freeform lewat shell (lebih ampuh daripada ActivityOptions). */
    fun openFloatingShizuku(ctx: Context, pkg: String): Boolean {
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString() ?: return false
        return shizukuShell(arrayOf("am", "start", "-n", comp, "--windowingMode", "5"))
    }

    /** "freeform" bila perangkat mendukung jendela asli, selain itu "web". */
    fun floatSupport(ctx: Context): String = if (freeformOn(ctx)) "freeform" else "web"

    /** Membuka aplikasi sebagai jendela freeform pada posisi tertentu. */
    fun openFloatingBounds(ctx: Context, pkg: String, bounds: Rect): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val opts = ActivityOptions.makeBasic()
            opts.setLaunchBounds(bounds)
            try {
                // WINDOWING_MODE_FREEFORM = 5 (API tersembunyi, dicoba lewat refleksi)
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Integer.TYPE)
                    .invoke(opts, 5)
            } catch (e: Throwable) {
                // tidak tersedia di perangkat ini
            }
            ctx.startActivity(intent, opts.toBundle())
            true
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------ Alat cepat

    private var torchOn = false

    fun torch(ctx: Context): Boolean = torchOn

    /** Senter tanpa izin tambahan. Mengembalikan status senter setelah diubah. */
    fun setTorch(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            torchOn = on
            on
        } catch (e: Exception) {
            torchOn
        }
    }

    fun canWriteSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    /** Kecerahan 0..100. Mengembalikan -1 bila tidak terbaca. */
    fun brightness(ctx: Context): Int = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255
    } catch (e: Exception) {
        -1
    }

    fun setBrightness(ctx: Context, pct: Int): Boolean {
        if (!canWriteSettings(ctx)) return false
        return try {
            Settings.System.putInt(
                ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct.coerceIn(1, 100) * 255 / 100)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun autoRotate(ctx: Context): Boolean = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION) == 1
    } catch (e: Exception) {
        false
    }

    fun setAutoRotate(ctx: Context, on: Boolean): Boolean {
        if (!canWriteSettings(ctx)) return false
        return try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Membuka panel pengaturan cepat bawaan sistem (internet, volume). */
    fun openPanel(ctx: Context, action: String): Boolean = try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun batteryTemp(ctx: Context): Double {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 0.0
        return i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
    }

    fun volume(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (mx > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx else 0
    }

    fun setVolume(ctx: Context, pct: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, pct.coerceIn(0, 100) * mx / 100, 0)
        } catch (e: Exception) {
            // sebagian perangkat menolak saat Jangan Ganggu aktif
        }
    }

    /**
     * Pembersih: hapus cache aplikasi ini dan hentikan proses latar belakang
     * aplikasi lain. Mengembalikan perkiraan MB yang dibebaskan.
     */
    fun clean(ctx: Context): Double {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem

        var bytes = 0L
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { dir ->
            dir.listFiles()?.forEach { f ->
                if (!f.name.startsWith("org.chromium")) bytes += wipe(f)
            }
        }

        ctx.packageManager.getInstalledApplications(0).forEach { app ->
            val system = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!system && app.packageName != ctx.packageName) {
                am.killBackgroundProcesses(app.packageName)
            }
        }

        Thread.sleep(400)
        val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        return (bytes + maxOf(0L, after - before)) / 1048576.0
    }

    private fun wipe(f: File): Long {
        var n = 0L
        if (f.isDirectory) f.listFiles()?.forEach { n += wipe(it) }
        n += f.length()
        f.delete()
        return n
    }

    // ------------------------------------------------------------ Fitur tambahan

    /** "rx,tx" total byte jaringan sejak boot. */
    fun netBytes(): String =
        android.net.TrafficStats.getTotalRxBytes().toString() + "," + android.net.TrafficStats.getTotalTxBytes()

    /** RAM bebas dan total dalam MB. */
    fun ramMb(ctx: Context): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return Pair(mi.availMem / 1048576, mi.totalMem / 1048576)
    }

    /** Penyimpanan internal bebas dan total dalam GB. */
    fun storageGb(): Pair<Double, Double> {
        val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        return Pair(st.availableBytes / 1073741824.0, st.totalBytes / 1073741824.0)
    }

    fun maxHz(ctx: Context): Float {
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplay(android.view.Display.DEFAULT_DISPLAY)
        var m = d.refreshRate
        d.supportedModes.forEach { if (it.refreshRate > m) m = it.refreshRate }
        return m
    }

    fun curHz(ctx: Context): Float =
        (ctx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplay(android.view.Display.DEFAULT_DISPLAY).refreshRate

    /** Hz tinggi: menaikkan batas bawah refresh rate (butuh izin Ubah pengaturan sistem). */
    fun hzForced(ctx: Context): Boolean = try {
        Settings.System.getFloat(ctx.contentResolver, "min_refresh_rate", 0f) >= 90f
    } catch (e: Exception) {
        false
    }

    fun setHz(ctx: Context, on: Boolean): Boolean {
        if (!canWriteSettings(ctx)) return false
        return try {
            val hz = if (on) maxHz(ctx) else 0f
            Settings.System.putFloat(ctx.contentResolver, "min_refresh_rate", hz)
            Settings.System.putFloat(ctx.contentResolver, "peak_refresh_rate", if (on) hz else 0f)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Animasi cepat: skala animasi sistem 0.5x (butuh WRITE_SECURE_SETTINGS). */
    fun animFast(ctx: Context): Boolean = try {
        Settings.Global.getFloat(ctx.contentResolver, "animator_duration_scale", 1f) < 1f
    } catch (e: Exception) {
        false
    }

    fun setAnim(ctx: Context, on: Boolean): Boolean {
        if (!hasSecure(ctx)) return false
        return try {
            val v = if (on) 0.5f else 1f
            Settings.Global.putFloat(ctx.contentResolver, "window_animation_scale", v)
            Settings.Global.putFloat(ctx.contentResolver, "transition_animation_scale", v)
            Settings.Global.putFloat(ctx.contentResolver, "animator_duration_scale", v)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** DNS pribadi: "off", "google", "cloudflare", "adguard" (butuh WRITE_SECURE_SETTINGS). */
    fun dns(ctx: Context): String = try {
        val mode = Settings.Global.getString(ctx.contentResolver, "private_dns_mode")
        val host = Settings.Global.getString(ctx.contentResolver, "private_dns_specifier") ?: ""
        if (mode != "hostname") "off" else when (host) {
            "dns.google" -> "google"
            "one.one.one.one" -> "cloudflare"
            "dns.adguard.com" -> "adguard"
            else -> "off"
        }
    } catch (e: Exception) {
        "off"
    }

    fun setDns(ctx: Context, kind: String): Boolean {
        if (!hasSecure(ctx)) return false
        val host = when (kind) {
            "google" -> "dns.google"
            "cloudflare" -> "one.one.one.one"
            "adguard" -> "dns.adguard.com"
            else -> null
        }
        return try {
            if (host == null) {
                Settings.Global.putString(ctx.contentResolver, "private_dns_mode", "opportunistic")
            } else {
                Settings.Global.putString(ctx.contentResolver, "private_dns_specifier", host)
                Settings.Global.putString(ctx.contentResolver, "private_dns_mode", "hostname")
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Waktu sambung TCP ke host:port dalam ms, -1 bila gagal. */
    fun tcpPing(host: String, port: Int): Int = try {
        val t0 = System.nanoTime()
        java.net.Socket().use { s ->
            s.connect(java.net.InetSocketAddress(host, port), 3000)
        }
        ((System.nanoTime() - t0) / 1_000_000).toInt()
    } catch (e: Exception) {
        -1
    }

    /** Menyimpan gambar QRIS ke galeri agar bisa dipindai lewat aplikasi e-wallet. */
    fun saveQris(ctx: Context, kind: String): Boolean {
        val asset = if (kind == "panel") "qris_panel.png" else "qris.png"
        val label = if (kind == "panel") "QRIS_Panel_1000.png" else "QRIS_Premium_8000.png"
        if (android.os.Build.VERSION.SDK_INT < 29) return false
        return try {
            val v = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, label)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DulzFluu")
            }
            val uri = ctx.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out ->
                ctx.assets.open(asset).use { it.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
