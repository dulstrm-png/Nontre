# Dulz | strm — Android WebView APK

Project ini membungkus `index.html` menjadi aplikasi Android.

- Logo aplikasi memakai gambar yang diberikan.
- Tombol **Beli** mengarah ke `https://sociabuzz.com/dulstrm/tribe`.
- Halaman HTTP/HTTPS dibuka di dalam WebView aplikasi.
- Navigasi kembali memakai tombol Back Android.
- GitHub Actions otomatis membangun APK debug.

## Build di GitHub

1. Upload seluruh isi ZIP ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih workflow **Build Dulz Strm APK**.
4. Tekan **Run workflow** atau push ke `main`/`master`.
5. Setelah selesai, ambil APK dari **Artifacts** dengan nama `dulz-strm-debug-apk`.
