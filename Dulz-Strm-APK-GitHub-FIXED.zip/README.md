# Dulz | strm APK

Upload the contents of this ZIP directly to a GitHub repository.

Then open **Actions → Build Dulz Strm APK → Run workflow**.

The workflow file is `.github/workflows/mail.yml`.

The APK is produced as a GitHub Actions artifact named `Dulz-Strm-APK`.
