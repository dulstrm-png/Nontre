# Dulz Fluu

Aplikasi panel melayang. Tampilan dibuat dengan HTML (`app/src/main/assets/index.html`),
dibungkus WebView, dan dihubungkan ke fitur Android lewat jembatan `Android`.

## Cara build APK dengan GitHub Actions

1. Buat repositori baru di GitHub.
2. Unggah seluruh isi folder ini, termasuk folder `.github` (folder berawalan titik sering
   terlewat saat unggah lewat browser; kalau terlewat, buat file
   `.github/workflows/build.yml` secara manual dan salin isinya).
3. Buka tab **Actions**. Build berjalan otomatis setiap push ke `main` atau `master`.
   Untuk menjalankan manual: pilih **Build APK** lalu **Run workflow**.
4. Setelah selesai (sekitar 3 sampai 6 menit), buka run tersebut dan unduh artifact
   **DulzFluu-APK**. Di dalamnya ada `DulzFluu.apk`.
5. Pasang di HP. Izinkan pemasangan dari sumber tidak dikenal bila diminta.

APK yang dihasilkan adalah build debug yang sudah ditandatangani kunci debug, jadi langsung
bisa dipasang.

## Mengubah tampilan

Edit `app/src/main/assets/index.html`, commit, dan Actions akan membangun ulang APK.

## Fitur native

| Fitur | Cara kerja |
| --- | --- |
| Tampil di atas aplikasi lain | Layanan foreground `OverlayService` dengan jendela overlay |
| Izin | Tombol Izinkan membuka layar izin sistem yang sebenarnya |
| Buka aplikasi lain | `getLaunchIntentForPackage` berdasarkan nama paket |
| Pembersih | Hapus cache aplikasi dan hentikan proses latar belakang aplikasi lain |
| Mode Game | Layar tetap menyala selama panel aktif |

## Batasan

- FPS game yang sedang dimainkan tidak bisa dibaca aplikasi biasa tanpa akses root atau Shizuku.
  Panel native menampilkan Hz layar, RAM bebas, dan baterai. FPS di halaman utama adalah
  kelancaran tampilan aplikasi ini sendiri.
- Pembersih hanya bisa menghentikan proses latar belakang. Sistem Android bisa menjalankan
  ulang sebagian proses tersebut.

## Pembaruan: panel dua sisi dan aplikasi melayang

- Panel native mengikuti desain dua sisi: Jaringan (ping), Panas (suhu baterai), Senter,
  Layar (Hz dan RAM), Bersihkan, Mode Game, dan 8 slot aplikasi.
- Tombol Semua App membuka daftar seluruh aplikasi terpasang (ada kolom cari). Ketuk untuk
  membuka melayang, tekan lama untuk menaruhnya di slot panel. Slot kosong (+) membuka
  daftar pilihan. Tekan lama sebuah aplikasi di panel untuk menghapusnya.
- Aplikasi melayang di atas game:
  1. Jendela asli (freeform) bila perangkat mendukung. Pada sebagian HP perlu mengaktifkan
     "Aktifkan jendela freeform" di Opsi pengembang lalu memulai ulang.
  2. Bila tidak didukung, WhatsApp, Telegram, Instagram, Discord, YouTube, dan beberapa lainnya
     dibuka sebagai jendela web melayang. Tombol "Lepas" mengembalikan fokus ke game.
- Fitur Jangan Ganggu / Mode Fokus sudah dihapus.
- Fitur di menu Fitur: Suhu, Volume media, Senter, Kecerahan, Putar otomatis, Panel cepat.
- Tombol Alat di panel: Senter, Kecerahan, Volume, Putar otomatis, Panel internet dan suara,
  ukuran jendela melayang, dan tombol Nyalakan jendela asli.
- Izin baru: Ubah pengaturan sistem (untuk Kecerahan dan Putar otomatis).

## Agar SEMUA aplikasi bisa melayang (setup sekali)

Cara termudah: pasang dan jalankan aplikasi **Shizuku**, lalu di Dulz Fluu ketuk
**Pakai Shizuku** pada kartu Melayang untuk semua aplikasi dan izinkan di popup.
Cara ADB di bawah adalah cadangan.

Android tidak mengizinkan aplikasi biasa memaksa aplikasi lain menjadi jendela melayang.
Caranya adalah mengaktifkan jendela freeform sistem, dan itu butuh izin yang hanya bisa
diberikan lewat ADB, tanpa root:

1. Aktifkan Opsi pengembang, lalu Debugging nirkabel (atau pakai kabel USB ke komputer).
2. Jalankan sekali: `adb shell pm grant com.dulz.fluu android.permission.WRITE_SECURE_SETTINGS`
3. Buka Dulz Fluu, di Beranda ketuk Nyalakan pada kartu Melayang untuk semua aplikasi
   (atau tombol Alat, lalu Nyalakan, di panel melayang).

Setelah itu aplikasi apa pun dari daftar Semua App dibuka sebagai jendela asli yang bisa
digeser dan diubah ukurannya. Catatan: aplikasi yang sudah terbuka layar penuh sebaiknya
ditutup dulu dari recents agar terbuka melayang. Sebagian HP (misalnya yang membatasi freeform)
bisa menolak; di HP seperti itu WhatsApp, Telegram, dan sejenisnya tetap dibuka sebagai
jendela web.

## Kontrol jendela melayang (butuh Shizuku)

Saat aplikasi dibuka dari Semua App, jendelanya diberi bilah kontrol berujung bulat di atas dan
bawah: geser lewat judul, ubah ukuran lewat pegangan bawah, tombol tempel (kiri, kanan, atas,
bawah), kecilkan, besarkan, layar penuh, dan tutup (menghentikan aplikasi). Di Alat ada juga
Tangkapan layar dan Tutup semua jendela. Ukuran awal mengikuti pilihan Kecil, Sedang, Besar.

## Versi 2.0: tab tepi layar, kode unlock, toko Premium, Game Booster

### Tombol tab di tepi layar
Tombol bulat diganti tab tipis transparan yang menempel di tepi layar (seperti sidebar game).
Geser untuk memindah, lepas dan tab menempel ke tepi kiri atau kanan terdekat. Ketuk untuk membuka panel.

### Fitur dan kunci
Gratis: Panel melayang, Pembersih, Mode Game, Boost dasar, Ping, Suhu, Senter, Kecerahan, Volume, Putar otomatis,
Penyimpanan, Info perangkat, Tangkapan layar (Shizuku).

Terkunci (buka dengan kode atau Premium):

| Kode fitur | Fitur |
| --- | --- |
| `PREMIUM` | Semua fitur di bawah |
| `boost` | Game Booster Pro (profil boost, Boost & Main per game) |
| `hud` | HUD Monitor melayang (ping, unduh/unggah, RAM, suhu, Hz, baterai) |
| `netmon` | Monitor Jaringan Pro (kecepatan langsung, uji ping server) |
| `anim` | Animasi Cepat 0.5x |
| `hz` | Paksa Hz Tinggi |
| `dns` | DNS Cepat (Google, Cloudflare, AdGuard) |
| `float` | Jendela melayang untuk semua aplikasi |
| `theme` | Tema Kustom (warna sendiri) |

Pemeriksaan kunci juga dilakukan di sisi native (`Bridge.kt`), bukan hanya di tampilan.

### Kode sekali pakai
Ada 130 kode (50 PREMIUM dan 10 untuk tiap fitur). Daftar kode asli ada di file terpisah
`KODE_ADMIN_RAHASIA.csv` dan JANGAN diunggah ke GitHub. Di dalam APK hanya tersimpan hash SHA-256 kode
(`assets/codes.json`), sehingga kode tidak bisa dibaca dari APK.

Dua mode, ditentukan oleh `assets/config.json`:

1. **Offline** (`"backend": ""`): kode dicek lewat hash, lalu ditandai terpakai di HP itu. Kode yang sama masih
   bisa dipakai di HP lain. Pesanan dikirim lewat aplikasi email ke dulstrm@gmail.com.
2. **Online** (`"backend"` diisi URL Apps Script, lihat `backend/README.md`): kode benar-benar sekali pakai di
   semua HP, email notifikasi masuk otomatis, admin menekan Setujui, lalu kode muncul sendiri di aplikasi pembeli.

Untuk sistem toko yang sesuai alur (QRIS, notifikasi email, konfirmasi admin, kode muncul) gunakan mode online.

### Toko
Menu Toko menampilkan QRIS Rp 8.000, tombol Simpan QRIS ke galeri, formulir Saya sudah bayar, status pesanan,
kolom Tukar kode, dan status tiap fitur.

### Game Booster
Boost gratis: bersihkan memori dan Mode Game. Game Booster Pro: profil (RAM, Hz, animasi, HUD, DNS) dan
tombol Boost untuk membuka game setelah semuanya disiapkan, lalu Stop mengembalikan pengaturan.
Catatan: FPS game yang sedang berjalan tidak bisa dibaca tanpa root. Animasi Cepat dan DNS butuh izin yang sama
dengan Jendela melayang (Shizuku atau ADB), Hz tinggi butuh izin Ubah pengaturan sistem.
