package com.dulz.fluu

import android.app.ActivityManager
import android.app.ActivityOptions
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import java.io.File

internal fun lum(c: Int): Int =
    (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c)) / 1000

/** Palet warna yang dipakai panel native. */
internal class Pal(val bg: Int, val surface: Int, val text: Int, val accent: Int) {
    val onAccent: Int get() = if (lum(accent) > 150) 0xFF0B0C0F.toInt() else Color.WHITE
}

/** Versi web sebuah aplikasi, dipakai sebagai jendela melayang cadangan. */
internal class WebApp(val url: String, val desktop: Boolean)

object Sys {

    private val WEB: Map<String, WebApp> = mapOf(
        "com.whatsapp" to WebApp("https://web.whatsapp.com", true),
        "com.whatsapp.w4b" to WebApp("https://web.whatsapp.com", true),
        "org.telegram.messenger" to WebApp("https://web.telegram.org/k/", true),
        "com.instagram.android" to WebApp("https://www.instagram.com/", false),
        "com.facebook.katana" to WebApp("https://m.facebook.com/", false),
        "com.facebook.orca" to WebApp("https://www.messenger.com/", true),
        "com.discord" to WebApp("https://discord.com/app", true),
        "com.google.android.youtube" to WebApp("https://m.youtube.com/", false),
        "com.twitter.android" to WebApp("https://x.com/", false),
        "com.zhiliaoapp.musically" to WebApp("https://www.tiktok.com/", false),
        "com.spotify.music" to WebApp("https://open.spotify.com/", true),
        "com.google.android.gm" to WebApp("https://mail.google.com/mail/mu/", false)
    )

    internal fun web(pkg: String): WebApp? = WEB[pkg]

    /** Membuka aplikasi lain berdasarkan nama paket (layar penuh). */
    fun open(ctx: Context, pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** "freeform" bila perangkat mendukung jendela asli, selain itu "web". */
    fun floatSupport(ctx: Context): String {
        val feature = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        val enabled = try {
            Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1
        } catch (e: Exception) {
            false
        }
        return if (feature || enabled) "freeform" else "web"
    }

    /** Membuka aplikasi sebagai jendela freeform pada posisi tertentu. */
    fun openFloating(ctx: Context, pkg: String, bounds: Rect): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val opts = ActivityOptions.makeBasic()
            opts.setLaunchBounds(bounds)
            try {
                // WINDOWING_MODE_FREEFORM = 5 (API tersembunyi, dicoba lewat refleksi)
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Integer.TYPE)
                    .invoke(opts, 5)
            } catch (e: Throwable) {
                // tidak tersedia di perangkat ini
            }
            ctx.startActivity(intent, opts.toBundle())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun batteryTemp(ctx: Context): Double {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 0.0
        return i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
    }

    fun focusOn(ctx: Context): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    /** Mode Fokus memakai Jangan Ganggu. Mengembalikan false bila izin belum diberikan. */
    fun setFocus(ctx: Context, on: Boolean): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return true
    }

    fun volume(ctx: Context): Int {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (mx > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / mx else 0
    }

    fun setVolume(ctx: Context, pct: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, pct.coerceIn(0, 100) * mx / 100, 0)
        } catch (e: Exception) {
            // sebagian perangkat menolak saat Jangan Ganggu aktif
        }
    }

    /**
     * Pembersih: hapus cache aplikasi ini dan hentikan proses latar belakang
     * aplikasi lain. Mengembalikan perkiraan MB yang dibebaskan.
     */
    fun clean(ctx: Context): Double {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem

        var bytes = 0L
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { dir ->
            dir.listFiles()?.forEach { f ->
                if (!f.name.startsWith("org.chromium")) bytes += wipe(f)
            }
        }

        ctx.packageManager.getInstalledApplications(0).forEach { app ->
            val system = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!system && app.packageName != ctx.packageName) {
                am.killBackgroundProcesses(app.packageName)
            }
        }

        Thread.sleep(400)
        val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        return (bytes + maxOf(0L, after - before)) / 1048576.0
    }

    private fun wipe(f: File): Long {
        var n = 0L
        if (f.isDirectory) f.listFiles()?.forEach { n += wipe(it) }
        n += f.length()
        f.delete()
        return n
    }
}
