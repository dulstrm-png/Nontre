package com.dulz.fluu

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object {
        @Volatile
        var current: MainActivity? = null
    }

    private lateinit var web: WebView

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        web.post { web.evaluateJavascript("window.DulzShizuku&&DulzShizuku()", null) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0A0B0E"))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
        }
        // Semua navigasi eksternal diblokir; aplikasi hanya memuat halaman lokal.
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        web.addJavascriptInterface(Bridge(this), "Android")

        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // Shizuku tidak tersedia
        }

        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    /** Dipanggil panel native saat daftar aplikasi berubah. */
    fun syncFromNative() {
        web.post { web.evaluateJavascript("window.DulzSync&&DulzSync()", null) }
    }

    /** Dipanggil dari Bridge saat tema berubah agar bilah sistem mengikuti. */
    fun applyBars(bg: Int) {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        web.setBackgroundColor(bg)
        val light = lum(bg) > 150
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (light) mask else 0, mask)
        } else {
            @Suppress("DEPRECATION")
            var f = window.decorView.systemUiVisibility
            val mask = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            f = if (light) f or mask else f and mask.inv()
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = f
        }
    }

    private fun notifyResume() {
        web.evaluateJavascript("document.dispatchEvent(new Event('visibilitychange'))", null)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        notifyResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        notifyResume()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        if (current === this) current = null
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // abaikan
        }
        web.destroy()
        super.onDestroy()
    }
}
