/**
 * Backend Dulz Fluu (Google Apps Script) - gratis, tanpa server sendiri.
 *
 * Fungsi:
 *  - Menerima pesanan dari aplikasi dan mengirim email notifikasi ke admin.
 *  - Admin menekan tombol Setujui di email -> kode Premium otomatis diberikan ke pesanan itu.
 *  - Aplikasi mengecek status pesanan, lalu kode muncul di layar pembeli.
 *  - Setiap kode hanya bisa dipakai SATU KALI di semua HP.
 *
 * SETUP (sekali, sekitar 5 menit): lihat backend/README.md
 */

var ADMIN_EMAIL = 'dulstrm@gmail.com';
var ADMIN_KEY = 'GANTI_DENGAN_KATA_RAHASIA_PANJANG';   // wajib diganti
var PRICE = 8000;

function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }

function sheet_(name, headers) {
  var sh = ss_().getSheetByName(name);
  if (!sh) {
    sh = ss_().insertSheet(name);
    sh.appendRow(headers);
  }
  return sh;
}
function codes_()  { return sheet_('Codes',  ['code', 'type', 'used', 'used_by', 'used_at', 'assigned_order']); }
function orders_() { return sheet_('Orders', ['order', 'time', 'name', 'contact', 'device', 'amount', 'status', 'code']); }

function norm_(c) { return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function html_(t) { return HtmlService.createHtmlOutput('<meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;padding:24px">' + t + '</body>'); }

function doGet(e) {
  var p = (e && e.parameter) || {};
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    switch (p.a) {
      case 'order':   return order_(p);
      case 'status':  return status_(p);
      case 'redeem':  return redeem_(p);
      case 'approve': return decide_(p, true);
      case 'reject':  return decide_(p, false);
      default:        return json_({ ok: true, msg: 'Dulz Fluu backend aktif' });
    }
  } catch (err) {
    return json_({ ok: false, msg: 'Kesalahan server: ' + err });
  } finally {
    lock.releaseLock();
  }
}

// ---------------------------------------------------------------- Pesanan

function order_(p) {
  if (!p.dev) return json_({ ok: false, msg: 'Perangkat tidak dikenal' });
  var name = String(p.name || '').substring(0, 60);
  var contact = String(p.contact || '').substring(0, 60);
  if (!name) return json_({ ok: false, msg: 'Nama pengirim wajib diisi' });

  var sh = orders_();
  // batasi: satu pesanan menunggu per perangkat
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][4] === p.dev && rows[i][6] === 'PENDING') {
      return json_({ ok: true, order: rows[i][0], status: 'PENDING' });
    }
  }

  var id = 'DZ' + Utilities.getUuid().replace(/-/g, '').substring(0, 8).toUpperCase();
  sh.appendRow([id, new Date(), name, contact, p.dev, PRICE, 'PENDING', '']);

  var base = ScriptApp.getService().getUrl();
  var ok = base + '?a=approve&order=' + id + '&key=' + encodeURIComponent(ADMIN_KEY);
  var no = base + '?a=reject&order=' + id + '&key=' + encodeURIComponent(ADMIN_KEY);
  MailApp.sendEmail({
    to: ADMIN_EMAIL,
    subject: 'Pesanan Premium Dulz Fluu ' + id,
    htmlBody:
      '<p>Pesanan baru <b>Akses Premium Rp ' + PRICE + '</b> (QRIS).</p>' +
      '<p>ID: <b>' + id + '</b><br>Nama pengirim: ' + name + '<br>Kontak: ' + contact + '<br>Waktu: ' + new Date() + '</p>' +
      '<p>Cek dulu mutasi pembayaran Anda. Jika sudah masuk:</p>' +
      '<p><a href="' + ok + '" style="background:#16a34a;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">SETUJUI &amp; KIRIM KODE</a>' +
      ' &nbsp; <a href="' + no + '" style="background:#dc2626;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">TOLAK</a></p>' +
      '<p style="color:#666;font-size:12px">Jangan teruskan email ini, tautannya berisi kunci admin.</p>'
  });
  return json_({ ok: true, order: id, status: 'PENDING' });
}

function status_(p) {
  var rows = orders_().getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] === p.order && rows[i][4] === p.dev) {
      var st = rows[i][6];
      return json_({ ok: true, status: st, code: st === 'APPROVED' ? rows[i][7] : '' });
    }
  }
  return json_({ ok: false, msg: 'Pesanan tidak ditemukan' });
}

function decide_(p, approve) {
  if (p.key !== ADMIN_KEY) return html_('<h3>Kunci admin salah</h3>');
  var sh = orders_();
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] !== p.order) continue;
    if (rows[i][6] !== 'PENDING') return html_('<h3>Pesanan ' + p.order + ' sudah diproses: ' + rows[i][6] + '</h3>');
    if (!approve) {
      sh.getRange(i + 1, 7).setValue('REJECTED');
      return html_('<h3>Pesanan ' + p.order + ' ditolak.</h3>');
    }
    var cs = codes_();
    var cr = cs.getDataRange().getValues();
    for (var j = 1; j < cr.length; j++) {
      if (cr[j][1] === 'PREMIUM' && !cr[j][2] && !cr[j][5]) {
        cs.getRange(j + 1, 6).setValue(p.order);
        sh.getRange(i + 1, 7).setValue('APPROVED');
        sh.getRange(i + 1, 8).setValue(cr[j][0]);
        return html_('<h3>Disetujui</h3><p>Pesanan ' + p.order + ' mendapat kode:</p><p style="font-size:20px"><b>' + cr[j][0] + '</b></p><p>Kode juga muncul otomatis di aplikasi pembeli.</p>');
      }
    }
    return html_('<h3>Stok kode PREMIUM habis. Tambahkan kode baru di sheet Codes.</h3>');
  }
  return html_('<h3>Pesanan tidak ditemukan</h3>');
}

// ---------------------------------------------------------------- Kode

function redeem_(p) {
  var code = norm_(p.code);
  if (code.length < 8) return json_({ ok: false, msg: 'Kode tidak valid' });
  var sh = codes_();
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (norm_(rows[i][0]) !== code) continue;
    if (rows[i][2]) return json_({ ok: false, msg: 'Kode ini sudah pernah dipakai' });
    var order = rows[i][5];
    if (order) {
      // kode hasil pesanan hanya boleh dipakai perangkat pemesannya
      var od = orders_().getDataRange().getValues();
      for (var k = 1; k < od.length; k++) {
        if (od[k][0] === order && od[k][4] !== p.dev) return json_({ ok: false, msg: 'Kode ini milik pesanan lain' });
      }
    }
    sh.getRange(i + 1, 3, 1, 3).setValues([[true, p.dev || '', new Date()]]);
    return json_({ ok: true, type: rows[i][1] });
  }
  return json_({ ok: false, msg: 'Kode salah' });
}
