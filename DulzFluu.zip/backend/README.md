# Backend Dulz Fluu (gratis, Google Apps Script)

Tanpa backend, aplikasi tetap jalan: kode dicek di HP (sekali pakai per HP) dan pesanan dikirim lewat aplikasi email.
Dengan backend ini kode benar-benar sekali pakai di semua HP, email masuk otomatis, dan kode muncul sendiri
di aplikasi setelah Anda menyetujui.

## Setup (login dengan akun dulstrm@gmail.com)

1. Buka https://sheets.google.com, buat spreadsheet kosong baru (nama bebas, misal "Dulz Fluu DB").
2. Buat sheet bernama `Codes` (huruf besar C). Di baris 1 isi: `code, type, used, used_by, used_at, assigned_order`.
   Lalu impor `KODE_ADMIN_RAHASIA.csv` ke sheet itu (File > Import > Upload > Replace current sheet).
3. Menu Extensions > Apps Script. Hapus isi default, tempel seluruh isi `Code.gs`.
4. Ganti `ADMIN_KEY` dengan kata rahasia panjang buatan Anda sendiri. Simpan.
5. Deploy > New deployment > jenis **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
   - Klik Deploy, izinkan akses (kirim email + spreadsheet), salin **Web app URL**.
6. Di proyek Android, buka `app/src/main/assets/config.json`, isi `"backend"` dengan URL tadi.
7. Build ulang APK.

## Alur

1. Pembeli bayar QRIS, isi nama pengirim, tekan **Saya sudah bayar**.
2. Email masuk ke dulstrm@gmail.com berisi tombol **Setujui & kirim kode**.
3. Cek mutasi pembayaran, lalu tekan Setujui. Kode PREMIUM yang belum terpakai otomatis diberikan.
4. Di HP pembeli kode muncul otomatis, dan bisa langsung diaktifkan.

## Catatan

- Kode untuk fitur satuan (type `boost`, `hud`, `netmon`, `anim`, `hz`, `dns`, `float`, `theme`) dibagikan manual oleh admin.
- Stok kode PREMIUM menipis? Tambahkan baris baru di sheet `Codes` (kolom code dan type saja).
- Setelah mengubah `Code.gs`, buat **New deployment** lagi (atau Manage deployments > edit > New version) agar berlaku.
- Jangan unggah `KODE_ADMIN_RAHASIA.csv` ke GitHub. Isinya kode asli.
